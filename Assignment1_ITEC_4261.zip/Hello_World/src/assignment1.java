
public class assignment1 {

	public static void main(String[] args) {
		// Variables for purchasing stocks
		int numberOfStock = 1000;
		double purchasePrice = 32.87;
		double purchaseCommissionRate = 0.02;
		// Variables for stocks sold
		int numberShares = 1000;
		double soldPrice = 33.92;
		double soldCommissionRate = 0.02;
		
		// Calculate the total amount for stocks and commission
		double amountPaidForStock = numberOfStock * purchasePrice;
        double purchaseCommission = amountPaidForStock * purchaseCommissionRate;
        double amountSoldForStock = numberShares * soldPrice;
        double profit = amountSoldForStock - amountPaidForStock - purchaseCommission - soldCommissionRate;
        double soldCommission = amountSoldForStock * soldCommissionRate;
        
        
               
		// Display the result
        System.out.println("Amount Joe paid for the stock: $" + amountPaidForStock);
        System.out.println("Commission Joe paid when buying the stock: $" + purchaseCommission);
        System.out.println("Amount Joe sold the stock for: $" + amountSoldForStock);
        System.out.println("Commission Joe paid when selling the stock: $" + soldCommission);
        System.out.println("Profit after commissions: $" + profit);
	}

}
