package java_program_2;

import java.util.Scanner;

public class book_points_calculator {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the number of books purchased this month: ");
		int numBooks = scanner.nextInt();

		int points = calculatePoints(numBooks);
		System.out.println("Points awarded: " + points);
		scanner.close();

	}

	private static int calculatePoints(int numBooks) {
		// TODO Auto-generated method stub
		int points = 0;

		switch (numBooks) {
		case 0:
			points = 0;
			break;
		case 1:
			points = 5;
			break;
		case 2:
			points = 15;
			break;
		case 3:
			points = 30;
			break;
		case 4:
			points = 60;
			break;
		default:
			points = 60;// For 4 or more books, the points stay at 60 points.
		}
		return points;

	}

}
