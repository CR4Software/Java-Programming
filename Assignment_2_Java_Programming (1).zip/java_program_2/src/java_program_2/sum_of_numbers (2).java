package java_program_2;
import java.util.Scanner;
public class sum_of_numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   // Create a Scanner object to read input from the user
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a series of numbers separated by commas
        System.out.print("Enter a series of numbers separated by commas: ");
        String input = scanner.nextLine();

        // Close the scanner as we have obtained the input
        scanner.close();

        // Split the input string into an array of strings using commas as the delimiter
        String[] numbersAsString = input.split(",");

        // Initialize a variable to store the sum
        int sum = 0;

        // Iterate through the array and convert each string to an integer, then add to the sum
        for (String numberStr : numbersAsString) {
            try {
                int number = Integer.parseInt(numberStr.trim());
                sum += number;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter valid numbers separated by commas.");
                return;
            }
        }

        // Display the sum of the entered numbers
        System.out.println("Sum of the numbers: " + sum);
	}

}
