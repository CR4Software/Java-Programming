package assignment_3_java;
import java.util.Scanner;

public class Distance_Converter {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double meters;
        int choice;

        do {
            System.out.println("1. Convert to kilometers");
            System.out.println("2. Convert to inches");
            System.out.println("3. Convert to feet");
            System.out.println("4. Quit the program");
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter distance in meters: ");
                    meters = scanner.nextDouble();
                    double kilometers = meters * 0.001;
                    System.out.println(meters + " meters is " + kilometers + " kilometers.");
                    break;

                case 2:
                    System.out.print("Enter distance in meters: ");
                    meters = scanner.nextDouble();
                    double inches = meters * 39.37;
                    System.out.println(meters + " meters is " + inches + " inches.");
                    break;

                case 3:
                    System.out.print("Enter distance in meters: ");
                    meters = scanner.nextDouble();
                    double feet = meters * 3.281;
                    System.out.println(meters + " meters is " + feet + " feet.");
                    break;

                case 4:
                    System.out.println("Thank you, the program will now end.");
                    break;

                default:
                    System.out.println("Invalid choice. Reenter a valid choice.");
                    break;
            }

        } while (choice != 4);

        scanner.close();
    }
}
